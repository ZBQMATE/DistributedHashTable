package edu.buffalo.cse.cse486586.simpledht;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.HashSet;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicBoolean;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;
import android.util.Log;



public class SimpleDhtProvider extends ContentProvider {

    static final String TAG = SimpleDhtActivity.class.getSimpleName();
    static final String[] PORTS = {"11108","11112","11116","11120","11124"};
    static final String[] AVDS = {"5554","5556","5558","5560","5562"};
    static final int SERVER_PORT = 10000;
    private ArrayList<Integer> joinedavd = new ArrayList<Integer>();
    private int this_avd = 0;
    private HashSet<String> stored = new HashSet<String>();
    static final String cutter = "#Lzj#";
    static final String cutterb = "&Y Z&";
    private static int cnt = 0;
    private String qrs = "";
    private AtomicBoolean sys_q = new AtomicBoolean(false);
    private AtomicBoolean sys_qall = new AtomicBoolean(false);

    public int findavd(int mode) {
        // 1 for next, -1 for prev

        int id = this_avd;
        int flg = 0;
        try {
            //Log.v(TAG, "FINDAVD " + Integer.toString(joinedavd.size()));
            String this_hash = genHash(AVDS[this_avd]);
            String btm = "zzzz";
            if (mode == -1) {
                btm = "!!!!";
            }
            for (int i = 0; i < joinedavd.size(); i = i + 1) {
                //Log.v(TAG, "in joined avd " + AVDS[joinedavd.get(i)]);
                String avd_hash = genHash(AVDS[joinedavd.get(i)]);
                if (mode * avd_hash.compareTo(this_hash) > 0) {
                    if (mode * avd_hash.compareTo(btm) < 0) {
                        btm = avd_hash;
                        //id = i;
                        id = joinedavd.get(i);

                        flg = 1;
                    }
                }
            }
            if (flg == 0) {
                for (int i = 0; i < joinedavd.size(); i = i + 1) {
                    String avd_hash = genHash(AVDS[joinedavd.get(i)]);
                    if (mode * avd_hash.compareTo(btm) < 0) {
                        btm = avd_hash;
                        //id = i;
                        id = joinedavd.get(i);
                    }
                }
            }
        }
        catch(Exception e) {
            Log.e(TAG, "findavd failed");
        }
        return id;

    }


    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        // TODO Auto-generated method stub
        int nextavd = findavd(1);
        if (selection.equals("@")) {
            stored = new HashSet<String>();
        }
        else if (selection.equals("*")) {
            String msg = "ALLDEL" + cutter + AVDS[this_avd];
            new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, PORTS[nextavd]);
        }
        else {
            String msg = "DELETE" + cutter + selection;
            new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, PORTS[nextavd]);
        }



        return 0;
    }

    public int alldel(String start_point) {
        stored = new HashSet<String>();
        if (start_point.equals(AVDS[this_avd])) return 1;
        int nextavd = findavd(1);
        String msg = "ALLDEL" + cutter + start_point;
        new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, PORTS[nextavd]);
        return 0;
    }

    public int secondDelete(String key) {
        int prevavd = findavd(-1);
        int nextavd = findavd(1);
        try {
            String prev_hash = genHash(AVDS[prevavd]);
            String this_hash = genHash(AVDS[this_avd]);
            String key_hash = genHash(key);
            if (((key_hash.compareTo(prev_hash) > 0 && key_hash.compareTo(this_hash) < 0) || (prev_hash.equals(this_hash))) || (prev_hash.compareTo(this_hash) > 0 && (key_hash.compareTo(this_hash) < 0 || key_hash.compareTo(prev_hash) > 0))) {
                stored.remove(key);
            } else {
                String msg = "DELETE" + cutter + key;
                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, PORTS[nextavd]);
            }
        }
        catch(Exception e) {
            Log.e(TAG, "second delete failed");
        }
        return 0;
    }


    @Override
    public String getType(Uri uri) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        // TODO Auto-generated method stub
        int nextavd = findavd(1);
        //Log.v(TAG, "INSERT  " + Integer.toString(nextavd));
        String filename = (String) values.get("key");
        String string = (String) values.get("value");
        String msg = "INSERT" + cutter + filename + cutter + string;
        new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, PORTS[nextavd]);

        return uri;
    }


    public int secondInsert(String key, String value) {

        int prevavd = findavd(-1);
        int nextavd = findavd(1);
        try {
            Log.v(TAG, "nxavd  " + nextavd + " prvavd " + prevavd);
            String prev_hash = genHash(AVDS[prevavd]);
            String this_hash = genHash(AVDS[this_avd]);
            String key_hash = genHash(key);

            //Log.v(TAG, "i " + AVDS[prevavd] + AVDS[this_avd]);
            if (((key_hash.compareTo(prev_hash) > 0 && key_hash.compareTo(this_hash) < 0) || (prev_hash.equals(this_hash))) || (prev_hash.compareTo(this_hash) > 0 && (key_hash.compareTo(this_hash) < 0 || key_hash.compareTo(prev_hash) > 0))) {
                //Log.v(TAG, "insert here " + PORTS[this_avd]);
                String filename = key;
                String string = value;
                FileOutputStream outputStream;
                try {
                    outputStream = getContext().openFileOutput(filename, Context.MODE_PRIVATE);
                    outputStream.write(string.getBytes());
                    outputStream.close();
                    stored.add(filename);
                } catch (IOException e) {
                    Log.e(TAG, "File write failed");
                }
            } else {
                //Log.v(TAG, "pass to " + PORTS[nextavd]);
                String msg = "INSERT" + cutter + key + cutter + value;
                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, PORTS[nextavd]);
            }
        }
        catch(Exception e) {
            Log.e(TAG, "secondinsert failed");
        }

        return 0;
    }


    @Override
    public boolean onCreate() {
        // TODO Auto-generated method stub
        TelephonyManager tel = (TelephonyManager) getContext().getSystemService(Context.TELEPHONY_SERVICE);
        String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
        final String myPort = String.valueOf((Integer.parseInt(portStr) * 2));
        for (int i = 0; i < 5; i = i+1) {
            if (PORTS[i].equals(myPort)) {
                this_avd = i;
            }
        }
        try {
            /*
             * Create a server socket as well as a thread (AsyncTask) that listens on the server
             * port.
             *
             * AsyncTask is a simplified thread construct that Android provides. Please make sure
             * you know how it works by reading
             * http://developer.android.com/reference/android/os/AsyncTask.html
             */
            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);
        } catch (IOException e) {
            /*
             * Log is a good way to debug your code. LogCat prints out all the messages that
             * Log class writes.
             *
             * Please read http://developer.android.com/tools/debugging/debugging-projects.html
             * and http://developer.android.com/tools/debugging/debugging-log.html
             * for more information on debugging.
             */
            Log.e(TAG, "Can't create a ServerSocket");
            return false;
        }
        String msg = "INITIAL" + cutter + Integer.toString(this_avd);
        new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, PORTS[0]);

        return true;
    }


    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs,
                        String sortOrder) {
        // TODO Auto-generated method stub
        MatrixCursor cursor = new MatrixCursor(new String[]{"key", "value"});
        try {

            int nextavd = findavd(1);
            if (selection.equals("@")) {
                Iterator hiter = stored.iterator();
                for (String key : stored) {
                    // = hiter.next();
                    InputStreamReader ipta = new InputStreamReader(getContext().openFileInput(key));
                    BufferedReader br = new BufferedReader(ipta);
                    String value = br.readLine();
                    cursor.addRow(new Object[]{key, value});
                }
                return cursor;
            } else if (selection.equals("*")) {
                sys_qall.set(true);
                Log.v(TAG, "startGQ");
                qrs = "";
                String msg = "GLOBALQUERY" + cutter + PORTS[this_avd];
                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, PORTS[nextavd]);

                Log.v(TAG, "waitGQ");
                synchronized (sys_qall) {
                    while (sys_qall.get()) {
                        try {
                            sys_qall.wait();
                        }catch (Exception e){}
                    }
                }


                Log.v(TAG, qrs);
                String rst_list[] = qrs.split(cutterb);
                Log.v(TAG, "rst_list.length " + Integer.toString(rst_list.length));

                for (int i = 1; i < rst_list.length; i = i + 2) {
                    //Log.v(TAG, "this is " + rst_list[i]);
                    cursor.addRow(new Object[]{rst_list[i], rst_list[i + 1]});
                }

                Log.v(TAG, "why im dead");
                return cursor;
            } else {

                //Log.v(TAG, "AAA");
                sys_q.set(true);

                qrs = "";
                String msg = "QUERY" + cutter + selection + cutter + PORTS[this_avd];
                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, PORTS[nextavd]);

                //Log.v(TAG, "bbb" + PORTS[nextavd]);
                synchronized (sys_q){
                    while(sys_q.get()){
                        try{
                            sys_q.wait();
                        }catch(Exception e){}
                    }
                }

                cursor.addRow(new Object[]{selection, qrs});
                Log.v(TAG, "!!!result"+qrs);
                return cursor;
            }
        }
        catch(Exception e) {
            Log.e(TAG, "Query failed");
        }
        return cursor;
    }

    public int secondQuery(String key, String start_point) {
        int prevavd = findavd(-1);
        int nextavd = findavd(1);
        try {
            String prev_hash = genHash(AVDS[prevavd]);
            String this_hash = genHash(AVDS[this_avd]);
            String key_hash = genHash(key);
            if (((key_hash.compareTo(prev_hash) > 0 && key_hash.compareTo(this_hash) < 0) || (prev_hash.equals(this_hash))) || (prev_hash.compareTo(this_hash) > 0 && (key_hash.compareTo(this_hash) < 0 || key_hash.compareTo(prev_hash) > 0))) {

                try {
                    //Log.v(TAG, "ddd");
                    String value = "msi";
                    InputStreamReader ipta = new InputStreamReader(getContext().openFileInput(key));
                    BufferedReader br = new BufferedReader(ipta);
                    value = br.readLine();
                    MatrixCursor cursor = new MatrixCursor(new String[]{"key", "value"});
                    cursor.addRow(new Object[]{key, value});
                    //return cursor;
                    //Log.v(TAG, "eee");
                    String msg = "QUERST" + cutter + value;
                    new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, start_point);


                } catch (Exception e) {
                    Log.e(TAG, "secondQueryin failed");
                }

            } else {
                String msg = "QUERY" + cutter + key + cutter + start_point;
                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, PORTS[nextavd]);
            }
        }
        catch(Exception e) {
            Log.e(TAG, "secondQuery failed");
        }



        return 0;
    }

    public int snd(String prt, String msg) {

        new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, prt);

        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        // TODO Auto-generated method stub
        return 0;
    }

    private String genHash(String input) throws NoSuchAlgorithmException {
        MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
        byte[] sha1Hash = sha1.digest(input.getBytes());
        Formatter formatter = new Formatter();
        for (byte b : sha1Hash) {
            formatter.format("%02x", b);
        }
        return formatter.toString();
    }


    // servertask
    private class ServerTask extends AsyncTask<ServerSocket, String, Void> {

        @Override
        protected Void doInBackground(ServerSocket... sockets) {
            ServerSocket serverSocket = sockets[0];

            /*
             * TODO: Fill in your server code that receives messages and passes them
             * to onProgressUpdate().
             */

            Socket sk = null;
            String ss = "";
            while (1 == 1) {
                try {
                    sk = serverSocket.accept();
                    //ObjectInputStream ois = new ObjectInputStream(sk.getInputStream());

                    //ss = (String) ois.readObject();
                    InputStream is = sk.getInputStream();

                    byte[] messageRecieved = new byte[10000];
                    int messageLength = is.read(messageRecieved, 0, 10000);
                    for (int i = 0; i < messageLength; i++) {
                        ss += (char) messageRecieved[i];
                    }


                    //publishProgress(ss);
                    String msg_list[] = ss.split(cutter);
                    String msg_type = msg_list[0];
                    Log.v(TAG, "ServerTask GOT " + ss);
                    if (msg_type.equals("INITIAL")) {
                        int avdid = Integer.parseInt(msg_list[1]);
                        joinedavd.add(avdid);
                        String toall_msg = "AVDLIST";
                        for (int i = 0; i < joinedavd.size(); i = i + 1){
                            toall_msg = toall_msg + cutter + Integer.toString(joinedavd.get(i));
                        }
                        for (int i = 0; i < 5; i = i + 1) {
                            try {
                                String msgToSend = toall_msg;
                                //Socket socket;
                                String remotePort;
                                remotePort = PORTS[i];
                                /*
                                socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                        Integer.parseInt(remotePort));
                                if (msgToSend.length() > 0) {
                                    ObjectOutputStream stt = new ObjectOutputStream(socket.getOutputStream());
                                    stt.writeObject(msgToSend);
                                    stt.flush();
                                }
                                */
                                //Log.v(TAG, "TOALL MSG " + toall_msg);

                                Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                        Integer.parseInt(remotePort));
                                OutputStream os;
                                os = socket.getOutputStream();
                                byte[] ba = (msgToSend).getBytes();
                                os.write(ba);

                            } catch (UnknownHostException e) {
                                Log.e(TAG, "ClientTask UnknownHostException");
                            } catch (IOException e) {
                                Log.e(TAG, "ClientTask socket IOException");
                            }
                        }

                    }
                    if (msg_type.equals("AVDLIST")) {
                        joinedavd = new ArrayList<Integer>();
                        for (int i = 1; i < msg_list.length; i = i + 1) {

                            int avdid = Integer.parseInt(msg_list[i]);
                            joinedavd.add(avdid);
                            //Log.v(TAG, "joinedavd " + Integer.toString(avdid));
                        }
                    }
                    if (msg_type.equals("INSERT")) {
                        secondInsert(msg_list[1], msg_list[2]);
                    }
                    if (msg_type.equals("DELETE")) {
                        secondDelete(msg_list[1]);
                    }
                    if (msg_type.equals("ALLDEL")) {
                        alldel(msg_list[1]);
                    }
                    if (msg_type.equals("QUERY")) {
                        //Log.v(TAG, "ccc");
                        secondQuery(msg_list[1], msg_list[2]);
                    }
                    if (msg_type.equals("QUERST")) {
                        qrs = msg_list[1];
                        //Log.v(TAG, "fff");
                        synchronized (sys_q) {
                            sys_q.set(false);
                            sys_q.notify();
                        }
                    }
                    if (msg_type.equals("GLOBALQUERY")) {
                        String bse = "";
                        if (msg_list.length > 2) {
                            bse = msg_list[2];
                        }
                        Log.v(TAG, "GQ1");
                        Iterator hiter = stored.iterator();
                        for (String key : stored) {
                            //String key = hiter.next();
                            InputStreamReader ipta = new InputStreamReader(getContext().openFileInput(key));
                            BufferedReader br = new BufferedReader(ipta);
                            String value= br.readLine();
                            bse = bse + cutterb;
                            bse = bse + key;
                            bse = bse + cutterb;
                            bse = bse + value;
                        }
                        Log.v(TAG, "GQ2" + bse);
                        if (msg_list[1].equals(PORTS[this_avd])) {

                            qrs = bse;
                            Log.v(TAG, "GQ3");
                            synchronized (sys_qall) {
                                sys_qall.set(false);
                                sys_qall.notify();
                            }
                        }
                        else {
                            int nextavd = findavd(1);
                            String msg = "GLOBALQUERY" + cutter + msg_list[1] + cutter + bse;
                            Log.v(TAG, "GQ4");
                            snd(PORTS[nextavd], msg);
                            //new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, PORTS[nextavd]);
                        }
                    }






                } catch (IOException e) {
                    e.printStackTrace();
                }
                ss = "";
                if (sk == null) {
                    break;
                }
                if (sk.isInputShutdown()) {
                    break;
                }
            }

            return null;
        }


    }

    private class ClientTask extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... msgs) {
            String message = msgs[0];
            String port = msgs[1];


            try {
                /*
                String remotePort = REMOTE_PORT0;
                if (msgs[1].equals(REMOTE_PORT0))
                    remotePort = REMOTE_PORT1;



                 */

                String msgToSend = msgs[0];
                String targetPort = msgs[1];
                /*
                 * TODO: Fill in your client code that sends out a message.
                 */

                /*
                PrintWriter msg = new PrintWriter(socket.getOutputStream());
                */

                Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        Integer.parseInt(targetPort));
                OutputStream os;
                os = socket.getOutputStream();
                byte[] ba = (msgToSend).getBytes();
                os.write(ba);
                //Log.v(TAG, "ClientTask FINISH " + msgToSend);




                //Socket socket;
                //String remotePort;
                //remotePort = targetPort;
                //socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                //       Integer.parseInt(remotePort));
                //Log.v(TAG, "ClientTask READY TO FIRE");
                //if (msgToSend.length() > 0) {
                //    ObjectOutputStream stt = new ObjectOutputStream(socket.getOutputStream());
                //    stt.writeObject(msgToSend);
                //    stt.flush();
                //    Log.v(TAG, "ClientTask FINISH " + msgToSend);
                // }

                //socket.close();
            } catch (UnknownHostException e) {
                Log.e(TAG, "ClientTask UnknownHostException");
            } catch (IOException e) {
                Log.e(TAG, "ClientTask socket IOException");
            }



            return null;
        }


    }

}
